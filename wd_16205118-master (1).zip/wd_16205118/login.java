package check;
import java.io.*;
import java.util.Scanner;
public class login {
    public static void main(String[] args) throws IOException{
      	String path = "./mima.txt";//��ȡ�ļ�
		String[] content;
		String fileContent = "";
		fileContent = FileIO.readFile(path);
		content = fileContent.split("/");
		System.out.println("�������˺ţ�");
		Scanner input1 = new Scanner(System.in);
		String flag = input1.next();
		System.out.println("�������˺����룺");
		Scanner input2 = new Scanner(System.in);
		String flag2 = input1.next();
		if(flag.equals(content[0])&&flag2.equals(content[1])){
			System.out.println("������֤�ɹ���success");
		}
		else{
			System.out.println("������֤ʧ�ܣ�error");
		}
    	
		
    	
    	
      //  System.out.println(sha256hex(args[0]));
    }
    public static String sha256hex(String input) {
        return DigestUtils.sha256Hex(input);
    }
}
