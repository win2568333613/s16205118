package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	
	// inject via application.properties
    @Value("${welcome.message}")
    private String message;
	
    private List<String> tasks = Arrays.asList("Git", "Maven", "Gradle", "Spring", "Bootstrap", "jQuery", "MyBatis","Redis");
    private List<String> index=Arrays.asList("1","2","3","4","5","6","7","8","9","10");
    @GetMapping("/")
	public String index(Model model) {
    	
        model.addAttribute("tasks", tasks);
        model.addAttribute("message", message);
        model.addAttribute("index", index);
		return "welcome";		
	}
    @GetMapping("/add")
    public String add (String a,String  b,Model model ) {
    	 int m=0;
    	 int n=0;
    	 try {
    		 m=Integer.parseInt(a);
    		 n=Integer.parseInt(b);
       } catch (Exception e) {
    	   
       }
    	 model.addAttribute("a",a);
    	 model.addAttribute("b",b);
    	 model.addAttribute("result",m+n);
    	return index(model);
    }
}